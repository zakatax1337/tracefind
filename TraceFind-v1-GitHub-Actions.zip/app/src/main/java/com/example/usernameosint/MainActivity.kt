package com.example.usernameosint

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Target(val name: String, val url: String, val kind: String)

private val platforms = listOf(
    Target("Telegram", "https://t.me/%s", "telegram"),
    Target("GitHub", "https://github.com/%s", "code"),
    Target("Reddit", "https://www.reddit.com/user/%s/", "social"),
    Target("X", "https://x.com/%s", "social"),
    Target("Instagram", "https://www.instagram.com/%s/", "social"),
    Target("TikTok", "https://www.tiktok.com/@%s", "social"),
    Target("Twitch", "https://www.twitch.tv/%s", "social"),
    Target("YouTube", "https://www.youtube.com/@%s", "video")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TraceFindApp() }
    }
}

@Composable
fun TraceFindApp() {
    var username by remember { mutableStateOf("") }
    var searched by remember { mutableStateOf(false) }
    val context = LocalContext.current

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF0B0F14),
            surface = Color(0xFF121821),
            primary = Color(0xFF6EA8FE),
            secondary = Color(0xFF8BE9FD)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("TraceFind", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("Public username lookup", color = Color(0xFF8B98A8), fontSize = 13.sp)
                    }
                }

                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.removePrefix("@").trim() },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Username") },
                    leadingIcon = { Text("@", fontWeight = FontWeight.Bold) },
                    trailingIcon = {
                        if (username.isNotEmpty()) {
                            IconButton(onClick = { username = "" }) {
                                Icon(Icons.Default.Clear, "Clear")
                            }
                        }
                    }
                )

                Spacer(Modifier.height(10.dp))

                Button(
                    onClick = { searched = username.isNotBlank() },
                    enabled = username.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Искать публичные профили", fontSize = 16.sp)
                }

                Spacer(Modifier.height(18.dp))

                if (!searched) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF121821)),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Как это работает", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Приложение формирует ссылки на публичные страницы по введённому username. " +
                                "Результат открывается в браузере; пароль, номер телефона и закрытые данные не извлекаются.",
                                color = Color(0xFFB7C0CC), lineHeight = 20.sp
                            )
                        }
                    }
                } else {
                    Text("Результаты для @${username}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(platforms) { p ->
                            ResultCard(p, username) {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.url.format(username))))
                            }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    "Только открытые публичные страницы • v1.0",
                    color = Color(0xFF657181), fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

@Composable
fun ResultCard(p: Target, username: String, open: () -> Unit) {
    Card(
        onClick = open,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121821)),
        shape = RoundedCornerShape(15.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = Color(0xFF1D2733),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(p.name.take(1), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("Открыть публичный профиль", color = Color(0xFF8B98A8), fontSize = 12.sp)
            }
            Icon(Icons.Default.OpenInNew, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}
